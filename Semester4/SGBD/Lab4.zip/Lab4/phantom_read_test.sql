use Laborator3

exec phantomRead

select * from Students
select * from LogTable

delete from LogTable
delete from Students where id > 16