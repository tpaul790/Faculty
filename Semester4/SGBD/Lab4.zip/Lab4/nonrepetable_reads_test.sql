use Laborator3

exec nonRepeatableReads

select * from Students
select * from LogTable

delete from LogTable
update Students set name='Denis' where id = 16