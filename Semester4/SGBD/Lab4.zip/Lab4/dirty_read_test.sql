use Laborator3

exec dirtyRead

select * from Students
select * from LogTable

delete from LogTable
