use Laborator3

exec transaction2

select * from Students
select * from LogTable

delete from LogTable

update Students set name = 'Denis' where id = 16
update Students set name = 'Ionut' where id = 26