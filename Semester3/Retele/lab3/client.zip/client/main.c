#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>

int main() {
    struct sockaddr_in server;
    int c;
    uint16_t rez;
    char sir[1001];

    c = socket(AF_INET,SOCK_DGRAM,0);
    if(c<0){
        printf("Eroare la crearea socketului client\n");
        exit(0);
    }

    memset(&server,0,sizeof(server));
    server.sin_port = htons(1234);
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("Introduceti sirul: ");
    fgets(sir,1024,stdin);
    sir[strlen(sir)-1] = 0;

    uint16_t n = (uint16_t)strlen(sir);
    n = htons(n);
    sendto(c, &n, sizeof(n), 0, (struct sockaddr*) &server, sizeof(server));
    n = ntohs(n);
    sendto(c, sir, n-1, 0, (struct sockaddr*) &server, sizeof(server));

    unsigned int l = sizeof(server);
    recvfrom(c, &rez, sizeof(rez), MSG_WAITALL, (struct sockaddr*) &server, &l);
    rez = ntohs(rez);

    printf("Numarul de caractere spatiu este: %d\n",rez);
    return 0;
}
