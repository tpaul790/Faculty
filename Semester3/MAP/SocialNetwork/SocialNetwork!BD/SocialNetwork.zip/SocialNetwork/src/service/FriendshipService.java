package service;

import domain.Friendship;
import domain.Tuple;
import domain.User;
import domain.validation.ServiceException;
import repository.database.FriendshipDbRepo;
import repository.database.UserDbRepo;
import repository.file.FriendshipInFileRepo;
import repository.file.UserInFileRepo;
import utils.Utils;

import java.util.*;
import java.util.function.Function;

public class FriendshipService extends Service<Tuple<Integer,Integer>,Friendship,FriendshipDbRepo> {
    private UserDbRepo userInFileRepo;

    public FriendshipService(FriendshipDbRepo repository, UserDbRepo userInFileRepo) {
        super(repository);
        this.userInFileRepo = userInFileRepo;
    }


    public void delete(int id1, int id2) throws ServiceException {
        Optional<Friendship> rez = super.getRepository().delete(new Tuple<>(id1,id2));
        if(rez.isEmpty()){
            throw new ServiceException("No friendship found");
        }
    }

    public void deleteAllFriendshipsForUser(int userId) throws ServiceException {
        Optional<User> user = userInFileRepo.findOne(userId);
        if(user.isEmpty()){
            throw new ServiceException("No user found");
        }

        Set<Friendship> friendshipsToRemove = new HashSet<>();
        for(Friendship friendship : findAll()){
            if(friendship.getId().getSecond().equals(userId) || friendship.getId().getFirst().equals(userId)) {
                if(friendship.getStatus().equals("pending")) {
                    Optional<User> receiver = userInFileRepo.findOne(friendship.getId().getSecond());
                    receiver.ifPresent(value -> value.getFriendRequests().remove(friendship));
                }
                friendshipsToRemove.add(friendship);
            }
        }


        for (Friendship friendship : friendshipsToRemove)
            super.getRepository().delete(friendship.getId());

    }

    /**
     * Count the number of connected components from the friendship graph
     * @return the number of connected components
     */
    public int numberOfSocialComunities(){
        Map<User,Boolean> visited = new HashMap<>();
        int rez = 0;

        for(User user : userInFileRepo.findAll()){
            if(visited.get(user) == null) {
                rez++;
                Stack<User> stack = new Stack<>();
                stack.push(user);
                while (!stack.isEmpty()) {
                    user = stack.pop();
                    visited.put(user, true);
                    for(User friend : user.getFriends()){
                        if(visited.get(friend) == null) {
                            stack.push(friend);
                        }
                    }
                }
            }
        }
        return rez;
    }

    /**
     * Calculate the number of friendships between a set of users
     * @param users - the set of users
     * @return - the number of friendships
     */
    public int numberOfFriendships(Set<User> users){
        int rez = 0;
        Function<User,Integer> nrOfFriends = u -> u.getFriends().size();
        for(User user : users){
            rez += user.getFriends().size();
        }
        return rez/2;
    }

    /**
     * Find the most social comunity, with maximum friendships
     * @return - a set with all users that are part of the most social comunity
     */
    public Set<User> mostSocialComunity(){
        Map<User,Boolean> visited = new HashMap<>();
        Set<User> comunity = new HashSet<>();
        int maxi = -1;

        for(User user : userInFileRepo.findAll()){
            if(visited.get(user) == null) {
                Set<User> users = new HashSet<>();
                Stack<User> stack = new Stack<>();
                stack.push(user);
                while (!stack.isEmpty()) {
                    user = stack.pop();
                    users.add(user);
                    visited.put(user, true);
                    for(User friend : user.getFriends()){
                        if(visited.get(friend) == null) {
                            stack.push(friend);
                        }
                    }
                }
                int nrOfFriendships = numberOfFriendships(users);
                if(nrOfFriendships>maxi){
                    maxi = nrOfFriendships;
                    comunity = users;
                }
            }
        }
        return comunity;
    }

}
