package service;

import domain.Friendship;
import domain.Tuple;
import domain.User;
import domain.validation.ServiceException;
import repository.database.FriendshipDbRepo;
import repository.database.UserDbRepo;
import repository.file.FriendshipInFileRepo;
import repository.file.UserInFileRepo;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;

public class UserService extends Service<Integer, User, UserDbRepo>{
    private final FriendshipDbRepo friendshipRepo;

    public UserService(UserDbRepo userDbRepo, FriendshipDbRepo friendshipRepo) {
        super(userDbRepo);
        this.friendshipRepo = friendshipRepo;
        loadFriends();
    }

    private void loadFriends() {
        super.getRepository().loadFriends(friendshipRepo.findAll());
    }

    public void save(int id, String username, String email, String password, String role) throws ServiceException {
        User user = new User(id, username, email, password, role);
        Optional<User> rez = super.getRepository().save(user);
        Predicate<Optional<User>> present = Optional::isPresent;
        if(present.test(rez)) {
            throw new ServiceException("This user already exists");
        }
    }

    public void update(int id, String username, String email, String password, String role) throws ServiceException {
        User user = new User(id, username, email, password, role);
        Optional<User> rez = super.getRepository().update(user);
        Predicate<Optional<User>> present = Optional::isPresent;
        if(present.test(rez)) {
            throw new ServiceException("User not found");
        }
    }

    /**
     * The user with userId1 will send a friend request to the user with id userId2 and the friend request
     * will pe stored in the receiver's friendRequest list
     * @param userId1 - id of the user who send the friend request
     * @param userId2 - id of the user who receive the friend request
     */
    public void sendFriendRequest(int userId1, int userId2){
        Friendship friendship = new Friendship(new Tuple<>(userId1,userId2),"pending");
        super.getRepository().addFriendRequest(friendship);
        friendshipRepo.save(friendship);
    }

    /**
     * The friend request that the user with id userId1 send to the user with id userId2 will be accepted
     * and this two users will become friends, each of them will be stored in the other one friends list
     *
     * @param userId1 - id of the first user
     * @param userId2 - id of the second user
     */
    public void acceptFriendRequest(int userId1, int userId2) {
        User user1 = findOne(userId1);
        User user2 = findOne(userId2);
        user2.getFriendRequests().stream()
                .filter(friendship -> friendship.getId().getFirst().equals(userId1))
                .forEach(friendship -> {
                    friendship.setStatus("accepted");
                    friendship.setAcceptDate(LocalDate.now());
                    super.getRepository().addFriend(user1,user2);
                    friendshipRepo.save(friendship);
                });
    }

    /**
     * The friend request that the user with id userId1 send to the user with id userId2 will be declined
     * and the request will be removed from the receiver friendRequest list
     * @param userId1 - id of the first user
     * @param userId2 - id of the second user
     */
    public void declineFriendRequest(int userId1, int userId2){
        User user2 = findOne(userId2);
        user2.getFriendRequests().stream()
                .filter(friendship -> friendship.getId().getFirst().equals(userId1))
                .forEach(friendship -> {
                    friendship.setStatus("declined");
                    user2.getFriendRequests().remove(friendship);
                    friendshipRepo.delete(friendship.getId());
                });
    }

    public void removeFriend(int userId1, int userId2){
        User user1 = findOne(userId1);
        User user2 = findOne(userId2);
        super.getRepository().removeFriend(user1,user2);
    }

    /**
     *
     * @param id - the id of the user for which I want to accept all friend requests
     * @return - the number of friend requests that was accepted
     * @throws ServiceException - if user isn't t find or if there aren't t friend requests
     */
    public int acceptAllFriendRequests(int id) throws ServiceException {
        Set<Friendship> friendshipSet = (Set<Friendship>) friendshipRepo.findAllFriendRequests(id);
        if(friendshipSet.isEmpty()) {
            throw new ServiceException("You don't have friend requests!");
        }
        int size = friendshipSet.size();
        for(Friendship friendship : friendshipSet) {
            friendship.setStatus("accepted");
            friendship.setAcceptDate(LocalDate.now());
            friendshipRepo.update(friendship);
        }
        friendshipSet.clear();
        return size;
    }

    /**
     *
     * @param id - the id of the user for which I want to decline all friend requests
     * @return - the number of friend requests that was declined
     * @throws ServiceException - if there aren't friend requests
     */
    public int declineAllFriendRequests(int id) throws ServiceException {
        User user = findOne(id);
        int size = user.getFriendRequests().size();
        if(size == 0)
            throw new ServiceException("You don't have friend requests!");
        user.getFriendRequests().clear();
        return size;
    }

    public List<User> getAllFriends(int id) throws ServiceException {
        User user = findOne(id);
        return super.getRepository().getAllFriends(user);
    }
}
