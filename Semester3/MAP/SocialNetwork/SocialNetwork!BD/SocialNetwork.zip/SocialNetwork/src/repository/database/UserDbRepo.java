package repository.database;

import domain.Friendship;
import domain.User;
import domain.validation.RepoException;
import domain.validation.ValidationException;
import domain.validation.Validator;
import repository.Repository;
import repository.Repository2;

import javax.xml.transform.Result;
import java.sql.*;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;

public class UserDbRepo implements Repository2<Integer,User> {
    private String url;
    private String dbUsername;
    private String dbPassword;
    private Validator<User> validator;

    public UserDbRepo(String url, String username, String password,Validator<User> validator) {
        this.url = url;
        this.dbUsername = username;
        this.dbPassword = password;
        this.validator = validator;
    }

    @Override
    public Optional<User> findOne(Integer integer) {
        Optional<User> opUser = Optional.empty();
        try(Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword);
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM \"user\" WHERE id=?")){
            preparedStatement.setInt(1, integer);
            ResultSet result = preparedStatement.executeQuery();
            while(result.next()) {
                int id = result.getInt("id");
                String username = result.getString("username");
                String email = result.getString("email");
                String password = result.getString("password");
                String role = result.getString("role");
                opUser = Optional.of(new User(id, username, email, password, role));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return opUser;
    }

    @Override
    public Iterable<User> findAll() {
        Set<User> users = new HashSet<>();
        try(Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword);
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM \"user\"");
            ResultSet resultSet = preparedStatement.executeQuery()){
            while(resultSet.next()){
                int id = resultSet.getInt("id");
                String username = resultSet.getString("username");
                String password = resultSet.getString("password");
                String email = resultSet.getString("email");
                String role = resultSet.getString("role");
                users.add(new User(id,username,password,email,role));
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return users;
    }

    @Override
    public Optional<User> save(User entity) {
        int rez = -1;
        validator.validate(entity);
        try(Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword);
            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO \"user\"(id,username,email,password,role) VALUES (?,?,?,?,?)")){
            preparedStatement.setInt(1,entity.getId());
            preparedStatement.setString(2,entity.getUsername());
            preparedStatement.setString(3,entity.getEmail());
            preparedStatement.setString(4,entity.getPassword());
            preparedStatement.setString(5,entity.getRole());
            rez = preparedStatement.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
        }
        if(rez > 0)
            return Optional.empty();
        return Optional.of(entity);
    }

    @Override
    public Optional<User> delete(Integer id) {
        Optional<User> user = Optional.empty();
        try(Connection connection = DriverManager.getConnection(url,dbUsername,dbPassword);
            PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM \"user\" WHERE id = ?")){
            preparedStatement.setInt(1,id);
            user = findOne(id);
            if(user.isPresent())
                preparedStatement.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
        }
        return user; //empty daca nu exista userul si cu userul daca il sterge
    }

    @Override
    public Optional<User> update(User entity) {
        validator.validate(entity);
        Optional<User> opUser = Optional.empty();
        int rez = -1;
        try(Connection connection = DriverManager.getConnection(url,dbUsername,dbPassword);
            PreparedStatement preparedStatement = connection.prepareStatement("UPDATE \"user\" SET username=?,email=?,password=?,role=? WHERE id = ?")){
            preparedStatement.setString(1,entity.getUsername());
            preparedStatement.setString(2,entity.getEmail());
            preparedStatement.setString(3,entity.getPassword());
            preparedStatement.setString(4,entity.getRole());
            preparedStatement.setInt(5,entity.getId());
            rez = preparedStatement.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
        }
        if(rez > 0)
            return Optional.empty();
        return Optional.of(entity);
    }

    @Override
    public int size() {
        try(Connection connection = DriverManager.getConnection(url,dbUsername,dbPassword);
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT COUNT(*) FROM \"user\"");
            ResultSet result = preparedStatement.executeQuery()){
            return result.getInt(1);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Load for every user, that take part of a friendship, his friends or his friend requests
     * @param friendships - an iterable object that contains all friendships
     */
    public void loadFriends(Iterable<Friendship> friendships){
        for(Friendship friendship : friendships) {
            Optional<User> optionalUser1 = findOne(friendship.getId().getFirst());
            Optional<User> optionalUser2 = findOne(friendship.getId().getSecond());
            Predicate<Friendship> acceptedFriendship = f -> f.getStatus().equals("accepted");
            if(acceptedFriendship.test(friendship)) {
                if(optionalUser1.isPresent() && optionalUser2.isPresent()) {
                    optionalUser1.get().getFriends().add(optionalUser2.get());
                    optionalUser2.get().getFriends().add(optionalUser1.get());
                }
            }else if(acceptedFriendship.negate().test(friendship)) {
                optionalUser2.ifPresent(x -> x.getFriendRequests().add(friendship));
            }
        }
    }

    /**
     *
     * @param user1 - first user
     * @param user2 - second user
     * @throws domain.validation.ValidationException - if one of the users are invalid
     */
    public void addFriend(User user1, User user2) throws IllegalArgumentException {
        validator.validate(user1);
        validator.validate(user2);
        user1.getFriends().add(user2);
        user2.getFriends().add(user1);
    }

    /**
     *
     * @param user1 - first user
     * @param user2 - second user
     * @throws domain.validation.ValidationException - if one of the users are invalid
     */
    public void removeFriend(User user1, User user2) throws ValidationException {
        validator.validate(user1);
        validator.validate(user2);
        user1.getFriends().remove(user2);
        user2.getFriends().remove(user1);
    }


    /**
     *
     * @param friendRequest - friendship we want to add
     * @throws RepoException - if the friendship already exist
     */
    public void addFriendRequest(Friendship friendRequest) throws RepoException {
        serchForFriends(friendRequest);
        Optional<User> optionalReceiver = findOne(friendRequest.getId().getSecond());
        if(optionalReceiver.isPresent()) {
            if (optionalReceiver.get().getFriendRequests().contains(friendRequest)) {
                throw new RepoException("Friend request already exists");
            }
            optionalReceiver.get().getFriendRequests().add(friendRequest);
        }
    }


    public void removeFriendRequest(Friendship friendRequest) throws RepoException {
        serchForFriends(friendRequest);
        Optional<User> optionalReceiver = findOne(friendRequest.getId().getSecond());
        if(optionalReceiver.isPresent()) {
            if (!optionalReceiver.get().getFriendRequests().contains(friendRequest)) {
                throw new RepoException("Friend request not found");
            }
            optionalReceiver.get().getFriendRequests().remove(friendRequest);
        }
    }

    /**
     * Check if the friendship is valid, if the users that make the friendship exist
     * @param friendRequest - friendship that we want to check
     * @throws RepoException - if one of the users isn't find
     */
    private void serchForFriends(Friendship friendRequest) throws RepoException {
        Optional<User> sender = findOne(friendRequest.getId().getFirst());
        Optional<User> receiver = findOne(friendRequest.getId().getSecond());
        Predicate<Optional<User>> optionalNullUser = Optional::isEmpty;
        if(optionalNullUser.test(sender)) {
            throw new RepoException("Sender not found");
        }
        if(optionalNullUser.test(receiver)) {
            throw new RepoException("Receiver not found");
        }
    }

    public List<User> getAllFriends(User user) {
        return user.getFriends();
    }
}
