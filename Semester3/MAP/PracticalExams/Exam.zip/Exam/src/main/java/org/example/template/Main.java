package org.example.template;

public class Main {
    public static void main(String[] args){
        ApplicationStart.main(args);
    }
}
