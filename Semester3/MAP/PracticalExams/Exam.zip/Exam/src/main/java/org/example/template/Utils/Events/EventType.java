package org.example.template.Utils.Events;

public enum EventType {
    RESERVED,ADD_SPECTACOL
}
