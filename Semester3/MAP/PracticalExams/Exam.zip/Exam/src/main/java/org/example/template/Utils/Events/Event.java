package org.example.template.Utils.Events;

public interface Event {
}
