//
// Created by Titieni Paul on 11.03.2024.
//

#ifndef LAB2_4_DOMAIN_H
#define LAB2_4_DOMAIN_H

typedef struct{
    int id;
    char tip[21];
    char producator[21];
    char model[21];
    int pret;
    int cantitate;
}Produs;

typedef struct{
    Produs lista_produse[101];
    int lg;
}Lista;

int get_id(Produs*);

char* get_tip(Produs*);

char* get_producator(Produs*);

char* get_model(Produs*);

int get_pret(Produs*);

int get_cantitate(Produs*);

void set_pret(Produs* p, int new_pret);

void set_cantitate(Produs* p,int new_cant);

#endif //LAB2_4_DOMAIN_H
