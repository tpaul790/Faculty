#include "domain.h"

int get_id(Produs* p){
    return p->id;
}

char* get_tip(Produs* p){
    return p->tip;
}

char* get_producator(Produs* p){
    return p->producator;
}

char* get_model(Produs* p){
    return p->model;
}

int get_pret(Produs* p){
    return p->pret;
}

int get_cantitate(Produs* p){
    return p->cantitate;
}

void set_pret(Produs* p, int new_pret){
    p->pret=new_pret;
}

void set_cantitate(Produs* p,int new_cant){
    p->cantitate=new_cant;
}
