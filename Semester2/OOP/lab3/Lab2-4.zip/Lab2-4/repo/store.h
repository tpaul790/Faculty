//
// Created by Titieni Paul on 11.03.2024.
//

#ifndef LAB2_4_STORE_H
#define LAB2_4_STORE_H

#include "../domain/domain.h"

Lista creare_lista();
/*
    Funtctia creaza o lista vida
    return: functia returneaza lista creata
*/

Produs* find(Lista* list, int id);
/*
    Functia cauta produsul cu id-ul dat intr o lista data
    parametrii:
        -list: adresa listei in care se cauta
        -id: id ul produsul care se cauta,id>0
    return: functia returneaza adresa produsului cu id ul dat daca acesta exista in lista
            sau pointerul null in caz contrar
*/

void adaugare_produs(Lista* lista,Produs p);
/*
    Functia adauga un produs dat intr o lista data
    parametrii:
        lista: adresa listei in care se va adauga produsul
        p: produsul care se va adauga
    return:
*/

#endif //LAB2_4_STORE_H
