#include "repo.h"
#include "../Exceptii/exceptions.h"

void ProdusRepo::store(const Produs& p){
    for(int i=0;i<lista_produse.size();i++)
        if(lista_produse[i].get_producator()==p.get_producator() and lista_produse[i].get_tip()==p.get_tip() and
                lista_produse[i].get_nume()==p.get_nume() and lista_produse[i].get_pret()==p.get_pret())
            throw Exception("Exista deja acest produs!");

    lista_produse.push_back(p);
}

void ProdusRepo::sterge(const Produs& p,int poz){
    bool exista=false;
    for(int i=0;i<lista_produse.size();i++)
        if(lista_produse[i].get_producator()==p.get_producator() and lista_produse[i].get_tip()==p.get_tip() and
           lista_produse[i].get_nume()==p.get_nume() and lista_produse[i].get_pret()==p.get_pret())
            exista=true;
    if(!exista)
        throw Exception("Nu exista acest produs!");
    poz--;
    for(int i=poz+1;i<lista_produse.size();i++)
        lista_produse[i-1]=lista_produse[i];
    lista_produse.pop_back();
}

const MyVector<Produs>& ProdusRepo::get_all() const {
    return lista_produse;
}

void ProdusRepo::modifica(const Produs &p, const Produs &nou) {
    bool exista=false;
    for(int i=0;i<lista_produse.size();i++)
        if(lista_produse[i].get_producator()==p.get_producator() and lista_produse[i].get_tip()==p.get_tip() and
           lista_produse[i].get_nume()==p.get_nume() and lista_produse[i].get_pret()==p.get_pret()){
            exista=true;
            lista_produse[i].set_nume(nou.get_nume());
            lista_produse[i].set_tip(nou.get_tip());
            lista_produse[i].set_pret(nou.get_pret());
            lista_produse[i].set_producator(nou.get_producator());
        }
    if(!exista)
        throw Exception("Nu exista acest produs!");
}

void ProdusRepo::cauta(const Produs &p) {
    bool exista=false;
    for(int i=0;i<lista_produse.size();i++)
        if(lista_produse[i].get_producator()==p.get_producator() and lista_produse[i].get_tip()==p.get_tip() and
           lista_produse[i].get_nume()==p.get_nume() and lista_produse[i].get_pret()==p.get_pret())
            exista=true;
    if(!exista)
        throw Exception("Nu exista acest produs!");
}

