#ifndef LAB6_REPO_H
#define LAB6_REPO_H

#include "../Domain/produs.h"
#include "../MyVector/vector.h"
#include "../MyVector/Iterator.h"
#include <vector>
using std::vector;

class ProdusRepo{
private:
    MyVector<Produs> lista_produse;
    friend class Service;

public:
    ProdusRepo(const ProdusRepo& ot)=delete;

    ProdusRepo()=default;

    /*
     * Functia de stocare a unui produs in lista de produse
     * pram:
     *  -1: p, reprezinta produsul care se stocheaza
     * return:-
     */
    void store(const Produs& p);

    /*
     * Functia de stergere a unui produs din lista de produse
     * pram:
     *  -1: p, reprezinta produsul care se sterge
     * return:-
     */
    void sterge(const Produs& p, int poz);

    /*
     * Functia de modificare a unui produs de pe o poz data
     * pram:
     *  -1: p, reprezinta produsul care se stocheaza
     *  -3: poz, pozitia din lista e produsuli dat
     * return:-
     */
    void modifica(const Produs& p,const Produs& nou);

    /*
     * Functia de cautare a unui produs din lista de produse,functia arunca o exceptie daca produsul nu exista
     * iar daca nu exista,functia nu face nimic
     * pram:
     *  -1: p, reprezinta produsul care se cauta
     * return:-
     */
    void cauta(const Produs& p);

    /*
     * Functia returneaza lista curenta de produse
     * param:-
     * return: lista curenta de produse
     */
    const MyVector<Produs>& get_all() const;

};

#endif //LAB6_REPO_H
