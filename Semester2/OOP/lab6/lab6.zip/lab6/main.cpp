#include "Ui/ui.h"
#include "Service/service.h"
#include "Repo/repo.h"
//#include "Domain/produs.h"
#include "Teste/tests.h"

int main(){
    test_all();
    ProdusRepo repo;
    Service service{ repo };
    Ui ui{ service };
    ui.start();
//    Produs pr;
//    std::cout<<"S-au realizat: "<<pr.get_cnt()<<" de copi de produse.";
}