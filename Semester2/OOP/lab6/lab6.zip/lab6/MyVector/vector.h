#ifndef LAB6_VECTOR_H
#define LAB6_VECTOR_H

#include "../Domain/produs.h"

template<typename TElem>
class MyVectorIterator;

template<typename TElem>
class MyVector {
    friend class MyVectorIterator<TElem>;
private:
    int cp;
    int n;
    TElem* elems;
    void redimensionare();
public:
    MyVector();

    MyVector(const MyVector& ot);

    MyVector<TElem>& operator=(const MyVector<TElem>& ot);

    TElem& operator[](int poz) const;

    void push_back(const TElem& p);

    void pop_back();

    int size() const;

    bool empty() const;

    int get_cp() const;

    MyVectorIterator<TElem> iterator(){
        return MyVectorIterator<TElem>(*this);
    }

    MyVectorIterator<TElem> begin(){
        return MyVectorIterator<TElem>(*this,0);
    }

    MyVectorIterator<TElem> end(){
        return MyVectorIterator<TElem>(*this,n);
    }

    ~MyVector();
};

template<typename TElem>
MyVector<TElem>::MyVector() : cp{2},n{0},elems{new TElem[cp]}{}

template<typename TElem>
MyVector<TElem>::MyVector(const MyVector& ot){
    delete[] elems;
    auto* new_elems=new TElem[ot.cp];
    cp=ot.cp;
    n=ot.n;
    for(int i=0;i<ot.cp;i++)
        new_elems[i]=ot.elems[i];
    elems=new_elems;
}

template<typename TElem>
MyVector<TElem>& MyVector<TElem>::operator=(const MyVector<TElem>& ot){
    delete[] elems;
    auto* new_elems=new TElem[ot.cp];
    cp=ot.cp;
    n=ot.n;
    for(int i=0;i<ot.cp;i++)
        new_elems[i]=ot.elems[i];
    elems=new_elems;
    return *this;
}

template<typename TElem>
TElem& MyVector<TElem>::operator[](int poz) const{
    return elems[poz];
}

template<typename TElem>
void MyVector<TElem>::MyVector::push_back(const TElem &p) {
    if(n==cp)
        redimensionare();
    elems[n++]=p;
}

template<typename TElem>
void MyVector<TElem>::pop_back(){
    n--;
}

template<typename TElem>
int MyVector<TElem>::MyVector::size() const{
    return n;
}


template<typename TElem>
void MyVector<TElem>::MyVector::redimensionare() {
    auto* new_elems=new TElem[cp*2];
    cp*=2;
    for(int i=0;i<n;i++)
        new_elems[i]=elems[i];
    delete[] elems;
    elems=new_elems;
}

template<typename TElem>
int MyVector<TElem>::MyVector::get_cp() const{
    return cp;
}

template<typename TElem>
bool MyVector<TElem>:: empty() const{
    return n==0;
}

template<typename TElem>
MyVector<TElem>::~MyVector(){
    delete[] elems;
}


#endif //LAB6_VECTOR_H
