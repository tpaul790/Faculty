#include "../validari/validari.h"
#include "../Exceptii/exceptions.h"
#include "service.h"

void Service::add(const string &nume, const string &tip, int pret, const string &producator) {
    Produs p{nume, tip, pret,producator};
    string ers= validare_produs(p);
    if(!ers.empty())
        throw Exception(ers);
    repo.store(p);
}

const MyVector<Produs> &Service::get_all() const {
    return repo.get_all();
}

void Service::sterge_service(const string &nume, const string &tip, int pret, const string &producator) {
    Produs p{nume,tip,pret,producator};
    string ers= validare_produs(p);
    if(!ers.empty())
        throw Exception(ers);
    const auto& prods=repo.get_all();
    int poz=-1;
    for(int i=0;i<prods.size();i++){
        const auto& prod=prods[i];
        if(prod.get_producator()==p.get_producator() and prod.get_tip()==p.get_tip() and
           prod.get_nume()==p.get_nume() and prod.get_pret()==p.get_pret())
            poz=i;
    }
    repo.sterge(p,poz+1);
}

void Service::modifica_service(const string &nume, const string &tip, int pret, const string &producator,
                               const string &nume_nou, const string &tip_nou, int pret_nou,
                               const string &producator_nou) {
    Produs p{nume,tip,pret,producator};
    Produs nou{nume_nou,tip_nou,pret_nou,producator_nou};
    string ers= validare_produs(nou);
    if(!ers.empty())
        throw Exception(ers);
    repo.modifica(p,nou);
}

void Service::cauta_service(const string &nume, const string &tip, int pret, const string &producator) const {
    Produs p{nume,tip,pret,producator};
    //validare
    repo.cauta(p);
}

vector<Produs> Service::filtrare_pret(const int& pret) const {
    vector<Produs> f;
    const MyVector<Produs>& v=get_all();
    for(int i=0;i<v.size();i++)
        if(v[i].get_pret()==pret)
            f.push_back(v[i]);
    return f;
}

vector<Produs> Service::filtrare_nume(const string& nume) const {
    vector<Produs> f;
    const MyVector<Produs>& v=get_all();
    for(int i=0;i<v.size();i++)
        if(v[i].get_nume()==nume)
            f.push_back(v[i]);
    return f;
}

vector<Produs> Service::filtrare_producator(const std::string &producator) const {
    vector<Produs> f;
    const MyVector<Produs>& v=get_all();
    for(int i=0;i<v.size();i++)
        if(v[i].get_producator()==producator)
            f.push_back(v[i]);
    return f;
}

void Service::sortare_generica(int(*fct)(const Produs&, const Produs&),int ord) {
    if(ord==1) {
        for (int i = 0; i < repo.lista_produse.size()-1; i++)
            for(int j= i+1; j < repo.lista_produse.size(); j++)
                if (fct(repo.lista_produse[i], repo.lista_produse[j])==1) {
                    auto aux = repo.lista_produse[i];
                    repo.lista_produse[i] = repo.lista_produse[j];
                    repo.lista_produse[j] = aux;
                }
    }
    else{
        for (int i = 0; i < repo.lista_produse.size()-1; i++)
            for(int j= i+1; j < repo.lista_produse.size(); j++)
                if (fct(repo.lista_produse[i], repo.lista_produse[j])==0) {
                    auto aux = repo.lista_produse[i];
                    repo.lista_produse[i] = repo.lista_produse[j];
                    repo.lista_produse[j] = aux;
                }
    }
}

void Service::sortare_generica_2(int (*fct1)(const Produs &, const Produs &), int (*fct2)(const Produs &, const Produs &),int ord) {
    if(ord==1) {
        for (int i = 0; i < repo.lista_produse.size()-1; i++)
            for(int j= i+1; j < repo.lista_produse.size(); j++)
                if (fct1(repo.lista_produse[i], repo.lista_produse[j])==2) {
                    if(fct2(repo.lista_produse[i], repo.lista_produse[j])){
                        auto aux = repo.lista_produse[i];
                        repo.lista_produse[i] = repo.lista_produse[j];
                        repo.lista_produse[j] = aux;
                    }
                }else
                    if(fct1(repo.lista_produse[i], repo.lista_produse[j])){
                        auto aux = repo.lista_produse[i];
                        repo.lista_produse[i] = repo.lista_produse[j];
                        repo.lista_produse[j] = aux;
                }
    }
    else{
        for (int i = 0; i < repo.lista_produse.size()-1; i++)
            for(int j= i+1; j < repo.lista_produse.size(); j++)
                if (fct1(repo.lista_produse[i], repo.lista_produse[j])==2) {
                    if(!fct2(repo.lista_produse[i], repo.lista_produse[j])){
                        auto aux = repo.lista_produse[i];
                        repo.lista_produse[i] = repo.lista_produse[j];
                        repo.lista_produse[j] = aux;
                    }
                }else
                    if(!fct1(repo.lista_produse[i], repo.lista_produse[j])){
                        auto aux = repo.lista_produse[i];
                        repo.lista_produse[i] = repo.lista_produse[j];
                        repo.lista_produse[j] = aux;
                }
    }
}

