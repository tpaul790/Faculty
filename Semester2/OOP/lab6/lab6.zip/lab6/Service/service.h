#ifndef LAB6_SERVICE_H
#define LAB6_SERVICE_H

#include <string>
#include "../Repo/repo.h"

class Service{
private:
    ProdusRepo& repo;

public:
    /*
     * Constructorul service ului
     * param:
     *  1:repo, reprezinta un obiect de tip repo
     */
    explicit Service(ProdusRepo& rep):repo{rep}{}

    Service(const Service& ot)=delete;

    /*
     * Functia de adaugare a unui produs in service
     * param:
     *  1: nume, reprezinta numele produsului care se adauga
     *  2: tip, reprezinta tipul produsului care se adauga
     *  3: pret, reprezinta pretul produsului care se adauga
     *  4: producator, reprezinta producatorul produsului care se adauga
     * return:-
     */
    void add(const string& nume,const string& tip,int pret,const string& producator);

    /*
     * Functia de stergere a unui produs in service
     * param:
     *  1: nume, reprezinta numele produsului care se sterge
     *  2: tip, reprezinta tipul produsului care se sterge
     *  3: pret, reprezinta pretul produsului care se sterge
     *  4: producator, reprezinta producatorul produsului care se sterge
     * return:-
     */
    void sterge_service(const string& nume,const string& tip,int pret,const string& producator);

    /*
     * Functia de modificare a unui produs in service
     * param:
     *  1: nume, reprezinta numele produsului care se modifica
     *  2: tip, reprezinta tipul produsului care se modifica
     *  3: pret, reprezinta pretul produsului care se modifica
     *  4: producator, reprezinta producatorul produsului care se modifica
     *  5: nume, reprezinta noul nume
     *  6: tip, reprezinta noul tip
     *  7: pret, reprezinta noul pret
     *  8: producator, reprezinta noul producator
     * return:-
     */
    void modifica_service(const string& nume,const string& tip,int pret,const string& producator,const string& nume_nou,const string& tip_nou,int pret_nou,const string& producator_nou);

    /*
     * Functia de cautare a unui produs in service
     * param:
     *  1: nume, reprezinta numele produsului care se cauta
     *  2: tip, reprezinta tipul produsului care se cauta
     *  3: pret, reprezinta pretul produsului care se cauta
     *  4: producator, reprezinta producatorul produsului care se cauta
     * return:-
     */
    void cauta_service(const string& nume,const string& tip,int pret,const string& producator) const;

    /*
     * Functia de filtrare a produselor dupa pret
     * param:
     *  -1: pret, reprezinta pretul dupa care se filtreaza
     * return: returneaza o lista cu toate produsele care au pretul dat
     */
    vector<Produs> filtrare_pret(const int& pret) const;

    /*
     * Functia de filtrare a produselor dupa nume
     * param:
     *  -1: nume, reprezinta numele dupa care se filtreaza
     * return: returneaza o lista cu toate produsele care au numele dat
     */
    vector<Produs> filtrare_nume(const string& nume) const;

    /*
     * Functia de filtrare a produselor dupa producator
     * param:
     *  -1: producator, reprezinta producatorul dupa care se filtreaza
     * return: returneaza o lista cu toate produsele care au producatorul dat
     */
    vector<Produs> filtrare_producator(const string& producator) const;

    /*
     * Functia generica de sortare dupa un singur criteriu
     * param:
     *  -1: fct, reprezinta pointer catre functia de comparare
     *  -2: ord, ordinea dupa care se sorteaza(1-cresc,2-descresc)
     * return:-
     */
    void sortare_generica(int(*fct)(const Produs&, const Produs&),int ord);

    /*
     * Functia generica de sortare dupa doua criterii
     * param:
     *  -1: fct1, reprezinta pointer catre functia principala de comparare
     *  -2: fct2, reprezinta pointer catre functia secundara de comparare
     *  -3: ord, ordinea dupa care se sorteaza(1-cresc,2-descresc)
     * return:-
     */
    void sortare_generica_2(int(*fct1)(const Produs&, const Produs&),int(*fct2)(const Produs&, const Produs&),int ord);

    /*
     * Functia reprezinta un geter al listei de produse
     * param:-
     * return: returneaza lista de produse
     */
    const MyVector<Produs>& get_all() const;

};

#endif //LAB6_SERVICE_H
