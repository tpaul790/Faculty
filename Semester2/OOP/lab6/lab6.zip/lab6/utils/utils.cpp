#include "../Domain/produs.h"

int cmp_pret(const Produs& p1,const Produs& p2){
    if(p1.get_pret()>p2.get_pret())
        return 1;
    return 0;
}

int cmp_nume(const Produs& p1,const Produs& p2){
    if(p1.get_nume()>p2.get_nume())
        return 1;
    else if(p1.get_nume()<p2.get_nume())
        return 0;
    return 2;
}

int cmp_tip(const Produs& p1,const Produs& p2){
    if(p1.get_tip()>p2.get_tip())
        return 1;
    return 0;
}