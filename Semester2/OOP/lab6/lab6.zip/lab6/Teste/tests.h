#ifndef LAB6_TESTS_H
#define LAB6_TESTS_H

void test_all();

#endif //LAB6_TESTS_H
