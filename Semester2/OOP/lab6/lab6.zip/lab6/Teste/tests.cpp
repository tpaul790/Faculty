#include "../Domain/produs.h"
#include "../Exceptii//exceptions.h"
#include "../MyVector/vector.h"
#include "../MyVector/Iterator.h"
#include "../Repo/repo.h"
#include "../Service/service.h"
#include "../utils/utils.h"
#include <cassert>


//repo
void test_domain(){
    Produs p1{ "airpods", "casti", 8000, "apple" };
    Produs p2{ "iphone", "telefon", 312, "apple" };
    assert(p1.get_pret()==8000);
    assert(p1.get_nume()=="airpods");
    assert(p1.get_tip()=="casti");
    assert(p1.get_producator()=="apple");
    p1.set_nume("iphone");
    assert(p1.get_nume()=="iphone");
    p1.set_tip("telefon");
    assert(p1.get_tip()=="telefon");
    p1.set_pret(500);
    assert(p1.get_pret()==500);
    p1.set_producator("hp");
    assert(p1.get_producator()=="hp");
    assert(p1!=p2);
    if(p1==p2)
        assert(false);
    else
        assert(true);

    if(p1!=p1)
        assert(false);
    else
        assert(true);
}

void test_store(){
    ProdusRepo repo;
    Produs p1{ "airpods", "casti", 8000, "apple" };
    Produs p2{ "iphone", "telefon", 47, "apple" };
    Produs p3{ "mac", "laptop", 65, "apple" };
    repo.store(p1);
    auto& prods=repo.get_all();
    assert(prods.size()==1);
    repo.store(p2);
    repo.store(p3);
    assert(prods.size()==3);
    try{
        repo.store(p1);
        assert(false);
    }catch (Exception& e){
        assert(true);
    }
}

void test_sterge(){
    Produs p1{ "airpods", "casti", 8000, "apple" };
    Produs p2{ "iphone", "telefon", 47, "apple" };
    Produs p3{ "iphone", "laptop", 65, "apple" };
    ProdusRepo repo;
    repo.store(p1);
    repo.store(p2);
    repo.store(p3);
    auto& prods=repo.get_all();
    assert(prods.size()==3);
    repo.sterge(p1,1);
    repo.sterge(p3,2);
    assert(prods.size()==1);
    assert(prods[0].get_nume()=="iphone");
    try{
        repo.sterge(p1,3);
        assert(false);
    }catch(Exception& ex){
        assert(true);
    }
}

void test_modifica(){
    Produs p1{ "airpods", "casti", 8000, "apple" };
    Produs p2{ "iphone", "telefon", 47, "apple" };
    ProdusRepo repo;
    repo.store(p1);
    repo.modifica(p1,p2);
    assert(repo.get_all()[0].get_nume()=="iphone");
    assert(repo.get_all()[0].get_tip()=="telefon");
    assert(repo.get_all()[0].get_pret()==47);
    assert(repo.get_all()[0].get_producator()=="apple");
    try{
        repo.modifica(p1,p2);
        assert(false);
    }catch(Exception& e){
        assert(true);
    }
}

void test_cauta(){
    Produs p1{ "iphone", "telefon", 47, "apple" };
    ProdusRepo repo;
    try {
        repo.cauta(p1);
        assert(false);
    }catch (Exception& e){
        assert(true);
    }
    repo.store(p1);
    repo.cauta(p1);
}

//exceptii
void test_get_mesaj(){
    try {
        throw Exception{"Exceptie"};
    }catch (Exception & ex){
        string mesaj=ex.get_mesaj();
        assert(mesaj.size()==8);
        assert(mesaj=="Exceptie");
    }
}

//service

void test_add(){
    ProdusRepo repo;
    Service serv { repo };
    serv.add("iphone", "telefon", 47, "apple");
    serv.add("mac", "telefon", 47, "apple");
    serv.add("airpods", "telefon", 47, "apple");
    try{
        serv.add("a", "a", 0, "a");
        assert(false);
    }catch(Exception& e){
        assert(true);
    }
    const auto& prods=serv.get_all();
    assert(prods.size()==3);
    assert(prods[0].get_nume()=="iphone");
    assert(prods[1].get_nume()=="mac");
    assert(prods[2].get_nume()=="airpods");
}

void test_sterge_service(){
    ProdusRepo repo;
    Service serv { repo };
    serv.add("iphone", "telefon", 47, "apple");
    serv.add("mac", "telefon", 47, "apple");
    serv.add("airpods", "telefon", 47, "apple");
    try{
        serv.sterge_service("a", "a", 0, "a");
        assert(false);
    }catch(Exception& e){
        assert(true);
    }
    auto& prods=serv.get_all();
    assert(prods.size()==3);
    serv.sterge_service("iphone", "telefon", 47, "apple");
    assert(prods.size()==2);
    try{
        serv.sterge_service("iphone", "telefon", 47, "apple");
        assert(false);
    }catch(Exception& e){
        assert(true);
    }
    serv.sterge_service("mac", "telefon", 47, "apple");
    assert(prods.size()==1);
    assert(prods[0].get_nume()=="airpods");
}

void test_modifica_service(){
    ProdusRepo repo;
    Service serv { repo };
    serv.add("iphone", "telefon", 47, "apple");
    serv.modifica_service("iphone", "telefon", 47, "apple","airpods", "casti", 47, "apple");
    assert(serv.get_all()[0].get_nume()=="airpods");
    assert(serv.get_all()[0].get_tip()=="casti");
    assert(serv.get_all()[0].get_pret()==47);
    assert(serv.get_all()[0].get_producator()=="apple");
    try{
        serv.modifica_service("iphone", "telefon", 47, "apple","a", "a", -1, "a");
        assert(false);
    }catch(Exception& e){
        assert(true);
    }
    try{
        serv.modifica_service("iphone", "telefon", 47, "apple","airpods", "casti", 47, "apple");
        assert(false);
    }catch(Exception& e){
        assert(true);
    }
}

void test_cauta_service(){
    ProdusRepo repo;
    Service serv { repo };
    try{
        serv.cauta_service("iphone", "telefon", 47, "apple");
        assert(false);
    }catch (Exception& e){
        assert(true);
    }
    serv.add("iphone", "telefon", 47, "apple");
    serv.cauta_service("iphone", "telefon", 47, "apple");
}

void test_filtrari(){
    ProdusRepo repo;
    Service serv { repo };
    serv.add("iphone", "telefon", 47, "apple");
    serv.add("mac", "telefon", 47, "apple");
    serv.add("airpods", "telefon", 21, "apple");
    assert(serv.filtrare_pret(47).size()==2);
    assert(serv.filtrare_nume("iphone").size()==1);
    assert(serv.filtrare_producator("apple").size()==3);
}

void test_sortare_generica(){
    Produs p1{ "airpods", "casti", 1, "apple" };
    Produs p2{ "iphone", "telefon", 3, "apple" };
    Produs p3{ "mac", "laptop", 2, "apple" };
    ProdusRepo repo;
    repo.store(p1);
    repo.store(p2);
    repo.store(p3);
    Service service{ repo };
    service.sortare_generica(cmp_pret,1);
    assert(service.get_all()[0].get_pret()==1);
    assert(service.get_all()[1].get_pret()==2);
    assert(service.get_all()[2].get_pret()==3);
    service.sortare_generica(cmp_pret,2);
    assert(service.get_all()[0].get_pret()==3);
    assert(service.get_all()[1].get_pret()==2);
    assert(service.get_all()[2].get_pret()==1);

    service.sortare_generica(cmp_nume,1);
    assert(service.get_all()[0].get_nume()=="airpods");
    assert(service.get_all()[1].get_nume()=="iphone");
    assert(service.get_all()[2].get_nume()=="mac");

    service.sortare_generica(cmp_nume,2);
    assert(service.get_all()[0].get_nume()=="mac");
    assert(service.get_all()[1].get_nume()=="iphone");
    assert(service.get_all()[2].get_nume()=="airpods");
}

void test_sortare_generica_2(){
    Produs p1{ "iphone", "laptop", 1, "apple" };
    Produs p2{ "airpods", "telefon", 3, "apple" };
    Produs p3{ "iphone", "vision", 2, "apple" };
    Produs p4{ "airpods", "casti", 2, "apple" };
    ProdusRepo repo;
    repo.store(p1);
    repo.store(p2);
    repo.store(p3);
    repo.store(p4);
    Service service{ repo };
    service.sortare_generica_2(cmp_nume,cmp_tip,1);
    assert(service.get_all()[0].get_nume()=="airpods");
    assert(service.get_all()[0].get_tip()=="casti");
    assert(service.get_all()[1].get_nume()=="airpods");
    assert(service.get_all()[1].get_tip()=="telefon");
    assert(service.get_all()[2].get_nume()=="iphone");
    assert(service.get_all()[2].get_tip()=="laptop");
    assert(service.get_all()[3].get_nume()=="iphone");
    assert(service.get_all()[3].get_tip()=="vision");
    service.sortare_generica_2(cmp_nume,cmp_tip,2);
    assert(service.get_all()[0].get_nume()=="iphone");
    assert(service.get_all()[0].get_tip()=="vision");
    assert(service.get_all()[1].get_nume()=="iphone");
    assert(service.get_all()[1].get_tip()=="laptop");
    assert(service.get_all()[2].get_nume()=="airpods");
    assert(service.get_all()[2].get_tip()=="telefon");
    assert(service.get_all()[3].get_nume()=="airpods");
    assert(service.get_all()[3].get_tip()=="casti");

}

void test_cmp(){

    Produs p1{ "Someica", "tractor", 8000, "fiat" };
    Produs p2{ "Iphone", "telefon", 47, "apple" };
    Produs p3{ "Iphone", "laptop", 65, "apple" };
    assert(cmp_pret(p1,p2)==1);
    assert(cmp_pret(p2,p1)==0);
    assert(cmp_nume(p1,p2)==1);
    assert(cmp_nume(p2,p1)==0);
    assert(cmp_nume(p2,p3)==2);
    assert(cmp_tip(p3,p1)==0);
    assert(cmp_tip(p1,p3)==1);
}

//MyVector
void test_vector(){
    MyVector<Produs> v;
    assert(v.empty());
    Produs p1{ "airpods", "casti", 8000, "apple" };
    Produs p2{ "iphone", "telefon", 47, "apple" };
    Produs p3{ "iphone", "laptop", 65, "apple" };
    v.push_back(p1);
    assert(!v.empty());
    assert(v.size()==1);
    assert(v.get_cp()==2);
    v.push_back(p2);
    assert(v.size()==2);
    assert(v.get_cp()==2);
    v.push_back(p3);
    assert(v.size()==3);
    assert(v.get_cp()==4);
}

void test_iterator(){
    MyVector<Produs> v;
    Produs p1{ "airpods", "casti", 1, "apple" };
    Produs p2{ "iphone", "telefon", 1, "apple" };
    Produs p3{ "iphone", "laptop", 1, "apple" };
    v.push_back(p1);
    v.push_back(p2);
    v.push_back(p3);
    MyVectorIterator<Produs> it=v.iterator();
    it.prim();
    assert(*it==p1);
    assert(*it!=p2);
    it.urmator();
    assert(*it==p2);
    it.urmator();
    assert(*it==p3);
    for(const auto& p : v)
        assert(p.get_pret()==1);
}

void test_all(){
    //domain
    test_domain();
    //repo
    test_store();
    test_sterge();
    test_modifica();
    test_cauta();
    //exceptii
    test_get_mesaj();
    test_sterge_service();
    //service
    test_add();
    test_sterge_service();
    test_modifica_service();
    test_cauta_service();
    test_filtrari();
    test_sortare_generica();
    test_sortare_generica_2();
    //vector
    test_vector();
    //iterator
    test_iterator();
    //utils
    test_cmp();
}