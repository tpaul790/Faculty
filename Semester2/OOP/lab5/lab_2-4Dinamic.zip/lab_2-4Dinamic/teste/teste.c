//
// Created by Știube Denis on 09.03.2024.
//
#include <string.h>
#include <assert.h>
#include "../utils/utils.h"
#include "../list/lista.h"
#include "../service/service.h"
#include "../teste/teste.h"


void test_creare(){
    Oferta* oferta = CreeazaOferta("munte", "Bucegi", "12-10-2021", 2000);
    assert(get_pret(oferta) == 2000);
    assert(strcmp((get_tip(oferta)), "munte") == 0);
    char zi[4], luna[4], an[6];
    assert(strcmp(get_zi(get_data(oferta), zi), "12") == 0);
    assert(strcmp(get_luna(get_data(oferta), luna), "10") == 0);
    assert(strcmp(get_an(get_data(oferta), an), "2021") == 0);
    DistrugeOferta(oferta);
}

void test_distrugere(){
    ListaOferte* lista = CreeazaVid((DestroyF)(DistrugeOferta));
    assert(lista->cp == 2);
    Oferta* oferta = CreeazaOferta("city break", "Londra", "10-08-2019", 3400);
    AdaugaOferta(lista, oferta);
    assert(lista->n == 1);
    DestroyList(lista);
}

void test_redimensionare(){
    ListaOferte* lista = CreeazaVid((DestroyF)(DistrugeOferta));
    assert(lista->cp == 2);
    Oferta* oferta1 = CreeazaOferta("munte", "Bucegi", "12-10-2023", 2000);
    Oferta* oferta2 = CreeazaOferta("mare", "Bucegi", "10-09-2021", 3000);
    AdaugaOferta(lista, oferta2);
    AdaugaOferta(lista, oferta1);
    Oferta *oferta3 = CreeazaOferta("city-break", "Paris", "16-12-2024", 1000);
    AdaugaOferta(lista, oferta3);
    assert(lista->cp == 4);
    assert(lista->n == 3);
    DestroyList(lista);
}

void test_egalitate(){
    char tip[] = "munte";
    char destinatie[] = "Bucegi";
    char data[] = "12-10-2021";
    int pret = 2000;
    char tip1[] = "munte";
    char destinatie1[] = "Bucegi";
    char data1[] = "12-10-2021";
    int pret1 = 2000;
    Oferta* oferta1, *oferta2;
    oferta1 = CreeazaOferta(tip, destinatie, data, pret);
    oferta2 = CreeazaOferta(tip1, destinatie1, data1, pret1);
    assert(Egalitate(oferta1, oferta2) == 1);
    DistrugeOferta(oferta1);
    DistrugeOferta(oferta2);
}

void test_cronologic(){
    char* data1 = "10-12-2020";
    char* data2 = "11-09-2023";
    assert(Cronologic(data1, data2));
    data1 = "24-12-2004";
    data2 = "09-07-2019";
    assert(!Cronologic(data2, data1));
    data1 = "10-06-2017";
    data2 = "13-06-2017";
    assert(Cronologic(data1, data2));
    assert(!Cronologic(data2, data1));
    data1 = "14-10-2018";
    data2 = "24-11-2018";
    assert(Cronologic(data1, data2));
    assert(!Cronologic(data2, data1));
}

void test_gasit(){
    ListaOferte* lista = CreeazaVid((DestroyF)(DistrugeOferta));
    Oferta *oferta1, *oferta2, *oferta3;
    oferta1 = CreeazaOferta("munte", "Bucegi", "12-10-2021", 2000);
    oferta2 = CreeazaOferta("mare", "Bucegi", "12-10-2021", 2000);
    oferta3 = CreeazaOferta("munte", "Bucegi", "12-10-2021", 3000);
    AdaugaOferta(lista, oferta2);
    AdaugaOferta(lista, oferta1);
    assert(GasesteOferta(lista, *oferta1) == 1);
    assert(GasesteOferta(lista, *oferta2) == 0);
    assert(GasesteOferta(lista, *oferta3) == -1);
    DestroyList(lista);
    DistrugeOferta(oferta3);
}

void test_adaugare(){
    ListaOferte* lista = CreeazaVid((DestroyF)(DistrugeOferta));
    assert(lista->n == 0);
    Oferta* oferta1 = CreeazaOferta("mare", "Spania", "10-10-2020", 1000);
    AdaugaOferta(lista, oferta1);
    assert(lista->n == 1);
    assert(!strcmp(get_tip(lista->oferte[0]), "mare"));
    assert(get_pret(lista->oferte[0]) == 1000);
    DestroyList(lista);
}

void test_add(){
    ListaOferte* lista = CreeazaVid((DestroyF)(DistrugeLista));
    Oferta* oferta1 = CreeazaOferta("mare", "Spania", "10-10-2020", 1000);
    ListaOferte* lista2 = CreeazaVid((DestroyF)(DistrugeOferta));

    add(lista2,oferta1);
    assert(lista2->n == 1);
    assert(!strcmp(get_tip(lista2->oferte[0]), "mare"));
    assert(get_pret(lista2->oferte[0]) == 1000);

    add(lista,lista2);
    assert(lista->n == 1);

    DestroyList(lista);
}

void test_stergere(){
    ListaOferte* lista = CreeazaVid((DestroyF)(DistrugeOferta));
    Oferta* oferta1 = CreeazaOferta("munte", "Bucegi", "12-10-2021", 2000);
    Oferta* oferta2 = CreeazaOferta("mare", "Bucegi", "12-10-2021", 2100);
    AdaugaOferta(lista, oferta1);
    AdaugaOferta(lista, oferta2);
    assert(lista->n == 2);
    Oferta* oferta3 = CreeazaOferta("city-break", "Madrid", "12-10-2021", 4000);
    AdaugaOferta(lista, oferta3);
    StergeOferta(lista, 2);
    assert(lista->n == 2);
    assert(get_pret(lista->oferte[0]) == 2000);
    assert(strcmp(get_tip(lista->oferte[0]), "munte") == 0);
    DestroyList(lista);

}

void test_modificare(){
    ListaOferte* lista = CreeazaVid((DestroyF)(DistrugeOferta));
    Oferta* oferta1 = CreeazaOferta("munte", "Bucegi", "12-10-2021", 2000);
    Oferta* oferta2 = CreeazaOferta("mare", "Bucegi", "12-10-2021", 2000);
    AdaugaOferta(lista, oferta2);
    AdaugaOferta(lista, oferta1);
    assert(lista->n == 2);
    Oferta* oferta3 = CreeazaOferta("city break", "Londra", "22-09-2024", 3600);
    ModificaOferta(lista, 2, oferta3);
    assert(get_pret(lista->oferte[1]) == 3600);
    assert(!strcmp(get_tip(lista->oferte[1]), "city break"));
    assert(lista->n == 2);
    DistrugeOferta(oferta3);
    DestroyList(lista);
}

void test_sortare(){
    BigList lista = CreeazaBig();
    Oferta* oferta1 = CreeazaOferta("munte", "Bucegi", "12-10-2023", 2000);
    Oferta* oferta2 = CreeazaOferta("mare", "Bucegi", "10-09-2021", 3000);
    AdaugaOferta(lista.ListO, oferta2);
    AdaugaOferta(lista.ListO, oferta1);
    Oferta *oferta3 = CreeazaOferta("city-break", "Paris", "16-12-2024", 1000);
    AdaugaOferta(lista.ListO, oferta3);
    assert(lista.ListO->n == 3);
    SortareGenerica(&lista, MaiMic, 0);
    assert(get_pret(lista.ListO->oferte[0]) == 1000);
    assert(get_pret(lista.ListO->oferte[1]) == 2000);
    assert(get_pret(lista.ListO->oferte[2]) == 3000);
    SortareGenerica(&lista, MaiMic, 1);
    assert(get_pret(lista.ListO->oferte[0]) == 3000);
    assert(get_pret(lista.ListO->oferte[1]) == 2000);
    assert(get_pret(lista.ListO->oferte[2]) == 1000);
    SortareGenerica(&lista, MaiMicData, 1);
    assert(get_pret(lista.ListO->oferte[0]) == 1000);
    assert(strcmp(get_tip(lista.ListO->oferte[2]), "mare") == 0);
    SortareGenerica(&lista, MaiMicData, 0);
    assert(get_pret(lista.ListO->oferte[0]) == 3000);
    assert(get_pret(lista.ListO->oferte[2]) == 1000);
    assert(!strcmp(get_data(lista.ListO->oferte[0]), "10-09-2021"));
    assert(!strcmp(get_data(lista.ListO->oferte[1]), "12-10-2023"));
    DistrugeBig(lista);
}

void test_sortare2(){
    BigList lista = CreeazaBig();
    Oferta* oferta1 = CreeazaOferta("munte", "Bucegi","12-10-2024" , 2000);
    Oferta* oferta2 = CreeazaOferta("mare", "Bucegi", "12-10-2023", 3000);
    AdaugaOferta(lista.ListO, oferta2);
    AdaugaOferta(lista.ListO, oferta1);
    Oferta *oferta3 = CreeazaOferta("city-break", "Paris", "12-10-2023", 2000);
    AdaugaOferta(lista.ListO, oferta3);
    assert(lista.ListO->n == 3);
    SortareGenerica2(&lista, MaiMic,MaiMicData, 0);
    assert(get_pret(lista.ListO->oferte[0]) == 2000);
    assert(get_pret(lista.ListO->oferte[1]) == 2000);
    assert(get_pret(lista.ListO->oferte[2]) == 3000);
    assert(strcmp(get_data(lista.ListO->oferte[0]),"12-10-2023") == 0);

    SortareGenerica2(&lista, MaiMic, MaiMicData, 1);
    assert(get_pret(lista.ListO->oferte[0]) == 3000);
    assert(get_pret(lista.ListO->oferte[1]) == 2000);
    assert(get_pret(lista.ListO->oferte[2]) == 2000);
    assert(strcmp(get_data(lista.ListO->oferte[2]),"12-10-2023") == 0);

    SortareGenerica2(&lista, MaiMicData, MaiMic , 1);
    assert(get_pret(lista.ListO->oferte[0]) == 2000);
    assert(strcmp(get_tip(lista.ListO->oferte[2]), "city-break") == 0);

    SortareGenerica2(&lista, MaiMicData,MaiMic, 0);
    assert(get_pret(lista.ListO->oferte[0]) == 2000);
    assert(get_pret(lista.ListO->oferte[2]) == 2000);
    assert(!strcmp(get_data(lista.ListO->oferte[0]), "12-10-2023"));
    assert(!strcmp(get_data(lista.ListO->oferte[1]), "12-10-2023"));
    DistrugeBig(lista);
}

void test_filtrare(){
    BigList lista = CreeazaBig();
    Oferta* oferta1 = CreeazaOferta("munte", "Bucegi", "12-10-2023", 2000);
    Oferta* oferta2 = CreeazaOferta("mare", "Bucegi", "10-09-2021", 3000);
    AdaugaOferta(lista.ListO, oferta2);
    AdaugaOferta(lista.ListO, oferta1);
    Oferta* oferta3 = CreeazaOferta("city break", "Paris", "16-12-2024", 1000);
    AdaugaOferta(lista.ListO, oferta3);
    ListaOferte* lista_filtrata_pret1 = FiltruPret(&lista, 2000, 1);
    ListaOferte* lista_filtrata_pret0 = FiltruPret(&lista, 2500, 0);
    assert(lista_filtrata_pret1->n == 2);
    assert(get_pret(lista_filtrata_pret1->oferte[0]) + get_pret(lista_filtrata_pret1->oferte[1]) == 3000);
    ListaOferte* lista_filtrata_tip = FiltruTip(&lista, "munte");
    assert(lista_filtrata_tip->n == 1);
    assert(!strcmp(get_tip(lista_filtrata_tip->oferte[0]), "munte"));
    ListaOferte* lista_filtrata_data = FiltruData(&lista, "12-10-2023");
    assert(lista_filtrata_data->n == 1);
    assert(!strcmp(get_tip(lista_filtrata_data->oferte[0]), "munte"));
    assert(lista_filtrata_pret0->n == 1);
    assert(get_pret(lista_filtrata_pret0->oferte[0]) == 3000);
    DistrugeBig(lista);
    DestroyList(lista_filtrata_pret1);
    DistrugeLista(lista_filtrata_tip);
    DistrugeLista(lista_filtrata_pret0);
    DistrugeLista(lista_filtrata_data);
}

void test_validare_pret(){
    int pret = 1000;
    assert(ValidarePret(pret));
    pret = -100;
    assert(!ValidarePret(pret));
}

void test_validare_tip() {
    char tip1[10] = "munte";
    char tip2[10] = "mare";
    char tip3[20] = "vacanta";
    assert(ValidareTip(tip1));
    assert(ValidareTip(tip2));
    assert(!ValidareTip(tip3));
}

void test_validare_data(){
    char data1[11] = "10-12-2023";
    char data2[11] = "35-10-2011";
    char data3[11] = "10-14-2019";
    char data4[11] = "10-11-04";
    char data5[11] = "1020";
    char data6[11] = "34-11-2024";
    char data7[11] = "30-02-2017";
    assert(ValidareData(data1));
    assert(!ValidareData(data2));
    assert(!ValidareData(data3));
    assert(!ValidareData(data4));
    assert(!ValidareData(data5));
    assert(!ValidareData(data6));
    assert(!ValidareData(data7));
}

void test_validare_oferta(){
    char tip[10] = "munte";
    char destinatie[20] = "Bucegi";
    char data[11] = "40-03-2010";
    int pret = 3000;
    Oferta* oferta = CreeazaOferta(tip, destinatie, data, pret);
    assert(!ValidareOferta(*oferta));
    DistrugeOferta(oferta);
}

void test_adauga_service(){
    BigList list=CreeazaBig();
    assert(list.ListO->n == 0);
    char tip[20] = "munte";
    char destinatie[20] = "Bucegi";
    char data[11] = "07-07-2023";
    int pret = 2000;
    AdaugaOfertaService(&list,  tip, destinatie, data, pret);
    assert(list.ListO->n == 1);
    strcpy(tip, "munt");
    int ok = AdaugaOfertaService(&list, tip, destinatie, data, pret);
    assert(list.ListO->n == 1);
    assert(ok == -1);
    strcpy(tip, "munte");
    DistrugeBig(list);
}

void test_sterge_service(){
    BigList list=CreeazaBig();
    assert(list.ListO->n == 0);
    char tip[20] = "munte";
    char destinatie[20] = "Bucegi";
    char data[11] = "07-07-2023";
    int pret = 2000;
    AdaugaOfertaService(&list, tip, destinatie, data, pret);
    assert(list.ListO->n == 1);
    StergeOfertaService(&list, 1);
    assert(list.ListO->n == 0);
    AdaugaOfertaService(&list, tip, destinatie, data, pret);
    assert(list.ListO->n == 1);
    int ok = StergeOfertaService(&list, 2);
    assert(list.ListO->n == 1);
    assert(ok == -1);
    DistrugeBig(list);
}

void test_modifica_service(){
    BigList list=CreeazaBig();
    assert(list.ListO->n == 0);
    char tip[20] = "munte";
    char destinatie[20] = "Bucegi";
    char data[11] = "07-07-2023";
    int pret = 2000;
    AdaugaOfertaService(&list, tip, destinatie, data, pret);
    assert(list.ListO->n == 1);
    ModificaOfertaService(&list, "mare", "Spania", "24-10-2021", 3000, 1);
    assert(list.ListO->n == 1);
    assert(strcmp(get_tip(list.ListO->oferte[0]), "mare") == 0);
    assert(get_pret(list.ListO->oferte[0]) == 3000);
    int ok = ModificaOfertaService(&list, "mar", "Spania", "20-10-2019", 3500, 1);
    assert(ok == -1);
    AdaugaOfertaService(&list, "city-break", "Madrid", "07-06-2022", 4500);
    assert(list.ListO->n == 2);
    assert(get_pret(list.ListO->oferte[1]) == 4500);
    int modificare = ModificaOfertaService(&list, "mare", "Spania", "24-10-2021", 3000, 2);
    assert(modificare == -1);
    assert(list.ListO->n == 2);
    assert(get_pret(list.ListO->oferte[1]) == 4500);
    modificare = ModificaOfertaService(&list, "mare", "Spania", "24-10-2021", 3000, 3);
    assert(modificare == -1);
    assert(list.ListO->n == 2);
    DistrugeBig(list);
}

void test_lista_liste(){
    BigList list=CreeazaBig();
    ListaOferte* listL=CreeazaVid((DestroyF)(DistrugeLista));

    AdaugaOfertaService(&list, "mare", "Spania", "24-10-2021", 120);
    AdaugareLista(listL, CopieLista(list.ListO));
    assert(listL->n==1);

    AdaugaOfertaService(&list, "munte", "Bucegi", "24-10-2021", 123);
    AdaugareLista(listL, CopieLista(list.ListO));
    assert(listL->n==2);

    AdaugaOfertaService(&list, "munte", "Bucegi", "24-10-2021", 123);
    AdaugareLista(listL, CopieLista(list.ListO));
    assert(listL->n==3);
    assert(listL->cp==4);

    ListaOferte* l=listL->oferte[2];
    assert(l->n==3);
    assert(l->cp==4);

    DistrugeBig(list);
    DestroyList(listL);
}

void test_copie_oferta(){
    Oferta* oferta1 = CreeazaOferta("munte", "Bucegi", "12-10-2021", 2000);
    Oferta* cpy= CopieOferta(oferta1);
    assert(get_pret(cpy)==2000);
    DistrugeOferta(oferta1);
    assert(strcmp(get_tip(cpy),"munte")==0);
    DistrugeOferta(cpy);

}

void test_copie_list(){
    BigList list=CreeazaBig();
    AdaugaOfertaService(&list, "mare", "Spania", "24-10-2021", 120);
    AdaugaOfertaService(&list, "munte", "Bucegi", "24-10-2021", 123);
    ListaOferte* cpy= CopieLista(list.ListO);
    assert(cpy->n==2);
    assert(cpy->cp==2);
    assert(get_pret(cpy->oferte[0])==120);
    assert(get_pret(cpy->oferte[1])==123);
    DistrugeLista(cpy);

    ListaOferte* cpy2= CopieLista(list.UndoL->oferte[list.UndoL->n-1]);
    assert(cpy2->n==1);
    assert(get_pret(cpy2->oferte[0])==120);
    DistrugeLista(cpy2);

    ListaOferte* cpy3= CopieLista(list.UndoL->oferte[list.UndoL->n-2]);
    assert(cpy3->n==0);
    assert(cpy3->cp==2);
    AdaugareLista(list.UndoL, CopieLista(cpy3));
    DistrugeLista(cpy3);
    assert(list.UndoL->n==3);

    DistrugeBig(list);
}

void test_undo(){
    BigList list=CreeazaBig();

    AdaugaOfertaService(&list, "mare", "Spania", "24-10-2021", 120);
    assert(list.UndoL->n==1);
    assert(list.ListO->n==1);

    AdaugaOfertaService(&list, "munte", "Bucegi", "24-10-2021", 123);
    assert(list.UndoL->n==2);
    assert(list.ListO->n==2);

    AdaugaOfertaService(&list, "munte", "Bucegi", "24-10-2021", 125);
    assert(list.ListO->n==3);
    assert(list.UndoL->n==3);

    Undo(&list);
//    for(int i=0;i<list->n;i++)
//        printf("Oferta %d: %s, %s, %s, %d \n", i + 1, get_tip(list->oferte[i]), get_destinatie(list->oferte[i]),
//               get_data(list->oferte[i]),get_pret(list->oferte[i]));
    assert(list.ListO->n==2);
    assert(list.UndoL->n==2);
    assert(get_pret(list.ListO->oferte[0])==120);
    assert(get_pret(list.ListO->oferte[1])==123);
    assert(strcmp(get_tip(list.ListO->oferte[0]),"mare")==0);
    assert(strcmp(get_tip(list.ListO->oferte[1]),"munte")==0);

    Undo(&list);
    assert(list.ListO->n==1);
    assert(list.UndoL->n==1);
    assert(get_pret(list.ListO->oferte[0])==120);
    assert(strcmp(get_tip(list.ListO->oferte[0]),"mare")==0);

    Undo(&list);
    assert(list.ListO->n==0);
    assert(list.UndoL->n==0);

    DistrugeBig(list);

}

void AllTests(){
    test_creare();
    test_distrugere();
    test_egalitate();
    test_cronologic();
    test_redimensionare();
    test_gasit();
    test_adaugare();
    test_stergere();
    test_modificare();
    test_sortare();
    test_sortare2();
    test_filtrare();
    test_validare_pret();
    test_validare_tip();
    test_validare_data();
    test_validare_oferta();
    test_adauga_service();
    test_sterge_service();
    test_modifica_service();
    test_lista_liste();
    test_undo();
    test_copie_oferta();
    test_copie_list();
    test_add();
}