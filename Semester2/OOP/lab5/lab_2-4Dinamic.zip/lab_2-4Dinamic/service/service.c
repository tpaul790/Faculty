//
// Created by Știube Denis on 12.03.2024.
//

#include "service.h"
#include "../list/lista.h"
#include "../utils/utils.h"
#include <string.h>

int AdaugaOfertaService(BigList* list,char tip[], char destinatie[], char data[], int pret){
    Oferta* oferta = CreeazaOferta(tip, destinatie, data, pret);
    if (!ValidareOferta(*oferta)){
        DistrugeOferta(oferta);
        return -1;
    }
    add(list->UndoL, CopieLista(list->ListO));
    add(list->ListO, oferta);
    return 0;
}

int StergeOfertaService(BigList* list, int poz){
    if (poz < 1 || poz > list->ListO->n)
        return -1; // nu este o pozitie valida in lista
    add(list->UndoL, CopieLista(list->ListO));
    StergeOferta(list->ListO, poz);
    return 0;
}

int ModificaOfertaService(BigList* list, char tip[], char destinatie[], char data[], int pret, int poz) {
    Oferta* oferta = CreeazaOferta(tip, destinatie, data, pret);
    if (poz < 1 || poz > list->ListO->n || GasesteOferta(list->ListO, *oferta) != -1 || !ValidareOferta(*oferta)) {
        DistrugeOferta(oferta);
        return -1; // nu este o pozitie valida in lista
    }
    add(list->UndoL, CopieLista(list->ListO));
    ModificaOferta(list->ListO, poz, oferta);
    DistrugeOferta(oferta);
    return 0; // oferta modificata s-a pus pe ultima pozitie in lista !! :)))
}

/*
void SortarePret(ListaOferte* lista, int crescator){
    int sortat = 0;
    while (!sortat) {
        sortat = 1;
        for (int i = 0; i < lista->n - 1; i++)
            if (crescator == 0) {
                if (get_pret(lista->oferte[i]) > get_pret(lista->oferte[i+1])){
                    Oferta* aux = lista->oferte[i];
                    lista->oferte[i] = lista->oferte[i+1];
                    lista->oferte[i+1] = aux;
                    sortat = 0;
                }
            }
            else {
                if (get_pret(lista->oferte[i]) < get_pret(lista->oferte[i+1])){
                    Oferta* aux = lista->oferte[i];
                    lista->oferte[i] = lista->oferte[i+1];
                    lista->oferte[i+1] = aux;
                    sortat = 0;
                }
            }
    }
}
void SortareData(ListaOferte* lista, int cronologic){
    int sortat = 0;
    while (!sortat) {
        sortat = 1;
        for (int i = 0; i < lista->n - 1; i++)
            if (cronologic == 0) {
                if (!Cronologic(get_data(lista->oferte[i]), get_data(lista->oferte[i+1]))){
                    Oferta* aux = lista->oferte[i];
                    lista->oferte[i] = lista->oferte[i+1];
                    lista->oferte[i+1] = aux;
                    sortat = 0;
                }
            }
            else {
                if (Cronologic(get_data(lista->oferte[i]), get_data(lista->oferte[i+1]))){
                    Oferta* aux = lista->oferte[i];
                    lista->oferte[i] = lista->oferte[i+1];
                    lista->oferte[i+1] = aux;
                    sortat = 0;
                }
            }
    }
}

*/
void SortareGenerica(BigList* list, int(*f)(Oferta*, Oferta*), int ordine){
    int sortat = 0;
    while (!sortat) {
        sortat = 1;
        for (int i = 0; i < list->ListO->n - 1; i++)
            if (ordine == 0) {
                if (!f(list->ListO->oferte[i], list->ListO->oferte[i+1])){
                    Oferta* aux = list->ListO->oferte[i];
                    list->ListO->oferte[i] = list->ListO->oferte[i+1];
                    list->ListO->oferte[i+1] = aux;
                    sortat = 0;
                }
            }
            else {
                if (f(list->ListO->oferte[i], list->ListO->oferte[i+1])){
                    Oferta* aux = list->ListO->oferte[i];
                    list->ListO->oferte[i] = list->ListO->oferte[i+1];
                    list->ListO->oferte[i+1] = aux;
                    sortat = 0;
                }
            }
    }
}

void SortareGenerica2(BigList* list, int(*f1)(Oferta*, Oferta*),int(*f2)(Oferta*, Oferta*),int ordine){
    int sortat = 0;
    while (!sortat) {
        sortat = 1;
        for (int i = 0; i < list->ListO->n - 1; i++)
            if (ordine == 0) {
                if (f1(list->ListO->oferte[i], list->ListO->oferte[i+1])==0){
                    Oferta* aux = list->ListO->oferte[i];
                    list->ListO->oferte[i] = list->ListO->oferte[i+1];
                    list->ListO->oferte[i+1] = aux;
                    sortat = 0;
                }
                else if(f1(list->ListO->oferte[i], list->ListO->oferte[i+1])==2){
                    if(f2(list->ListO->oferte[i], list->ListO->oferte[i+1])==0) {
                        Oferta *aux = list->ListO->oferte[i];
                        list->ListO->oferte[i] = list->ListO->oferte[i + 1];
                        list->ListO->oferte[i + 1] = aux;
                        sortat = 0;
                    }
                }
            }
            else {
                if (f1(list->ListO->oferte[i], list->ListO->oferte[i+1])==1){
                    Oferta* aux = list->ListO->oferte[i];
                    list->ListO->oferte[i] = list->ListO->oferte[i+1];
                    list->ListO->oferte[i+1] = aux;
                    sortat = 0;
                }
                else if(f1(list->ListO->oferte[i], list->ListO->oferte[i+1])==2){
                    if(f2(list->ListO->oferte[i], list->ListO->oferte[i+1])>=1) {
                        Oferta *aux = list->ListO->oferte[i];
                        list->ListO->oferte[i] = list->ListO->oferte[i + 1];
                        list->ListO->oferte[i + 1] = aux;
                        sortat = 0;
                    }
                }
            }
    }
}

ListaOferte* FiltruPret(BigList* list, int PretLimita, int maxim){
    ListaOferte* lista_filtrata = CreeazaVid((DestroyF)(DistrugeOferta));
    int i;
    for (i = 0; i < list->ListO->n; i++) {
        if (maxim == 0) {
            if (get_pret(list->ListO->oferte[i]) >= PretLimita) {
                Oferta *oferta = CopieOferta(list->ListO->oferte[i]);
                AdaugaOferta(lista_filtrata, oferta);
            }
        } else {
            if (get_pret(list->ListO->oferte[i]) <= PretLimita) {
                Oferta *oferta = CopieOferta(list->ListO->oferte[i]);
                add(lista_filtrata, oferta);
            }
        }
    }
    return lista_filtrata;
}

ListaOferte* FiltruTip(BigList* list, char tip[]){
    ListaOferte* lista_filtrata = CreeazaVid((DestroyF)(DistrugeOferta));
    for (int i = 0; i < list->ListO->n; i++){
        if (!strcmp(get_tip(list->ListO->oferte[i]), tip)) {
            Oferta *oferta = CopieOferta(list->ListO->oferte[i]);
            add(lista_filtrata, oferta);
        }
    }
    return lista_filtrata;
}

ListaOferte* FiltruData(BigList* list, char data[]){
    ListaOferte* lista_filtrata = CreeazaVid((DestroyF)(DistrugeOferta));
    for (int i = 0; i < list->ListO->n; i++) {
        if (!strcmp(get_data(list->ListO->oferte[i]), data)) {
            Oferta *oferta = CopieOferta(list->ListO->oferte[i]);
            add(lista_filtrata, oferta);
        }
    }
    return lista_filtrata;
}

int ValidareTip(char tip[]){
    int valid = 1;
    char* tip1, *tip2, *tip3;
    tip1 = "munte";
    tip2 = "mare";
    tip3 = "city-break";
    if (strcmp(tip, tip1) != 0 && strcmp(tip, tip2) != 0 && strcmp(tip, tip3) != 0)
        valid = 0;
    return valid;
}

int ValidareData(char data[]){
    int valid = 1;
    if (strlen(data) != 10)
        valid = 0;
    if (data[2] != '-' || data[5] != '-')
        valid = 0;
    if (strncmp(data+3, "12", 2) > 0)
        valid = 0;
    if (strncmp(data+3, "02", 2) == 0 && strncmp(data, "28", 2) > 0)
        valid = 0;
    if ((data[4]-'0') % 2 == 0){
        if (strncmp(data, "30", 2) > 0)
            valid = 0;
    }
    else{
        if (strncmp(data, "31", 2) > 0)
            valid = 0;
    }
    return valid;
}

int ValidarePret(int pret){
    return pret > 0;
}

int ValidareOferta(Oferta oferta){
    return ValidareTip(get_tip(&oferta)) * ValidareData(get_data(&oferta));
}

void Undo(BigList* list){
    list->UndoL->n--;
    ListaOferte* l=list->UndoL->oferte[list->UndoL->n];
    ListaOferte* cpy= list->ListO;
    list->ListO=l;
    DistrugeLista(cpy);
}
