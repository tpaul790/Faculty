//
// Created by Știube Denis on 18.03.2024.
//

#ifndef LAB_2_4_UI_H
#define LAB_2_4_UI_H

void Afisare(ListaOferte*);

void AdaugaOfertaUI(BigList*);

void StergeOfertaUI(BigList*);

void ModificaOfertaUI(BigList*);

void SortarePretOfertaUI(BigList*);

void SortareDataOfertaUI(BigList*);

void FiltruPretUI(BigList*);

void FiltruTipUI(BigList*);

void FiltruDataUI(BigList*);

void Meniu();

void run();

#endif //LAB_2_4_UI_H
