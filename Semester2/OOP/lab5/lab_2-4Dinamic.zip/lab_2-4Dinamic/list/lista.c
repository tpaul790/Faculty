//
// Created by Știube Denis on 12.03.2024.
//

#include "lista.h"
#include "../utils/utils.h"
#include <stdlib.h>


ListaOferte* CreeazaVid(DestroyF fct){
    ListaOferte* lista = (ListaOferte*)malloc(sizeof(ListaOferte));
    lista->cp = 2;
    lista->oferte = (void**)malloc(lista->cp*sizeof(void*));
    lista->n = 0;
    lista->destroy=fct;
    return lista;
}

BigList CreeazaBig(){
    BigList list;
    list.ListO=CreeazaVid((DestroyF)(DistrugeOferta));
    list.UndoL=CreeazaVid((DestroyF)(DistrugeLista));
    return list;
}

void DistrugeLista(ListaOferte* lista){
    for (int i = 0; i < lista->n; i++){
        DistrugeOferta(lista->oferte[i]);
    }
    free(lista->oferte);
    free(lista);
}


//void DistrugeLista2(ListaOferte* list){
//    for(int i=0;i<list->n;i++)
//        DistrugeLista(list->oferte[i]);
//    free(list->oferte);
//    free(list);
//}

void DestroyList(ListaOferte* list){
    for(int i=0;i<list->n;i++)
        list->destroy(list->oferte[i]);
    free(list->oferte);
    free(list);
}

//void DestroyMyList(ListaOferte* list){
//    free(list->oferte);
//    free(list);
//}

void DistrugeBig(BigList list){
    DestroyList(list.ListO);
    DestroyList(list.UndoL);
}


void RedimensionareLista(ListaOferte* lista){
    void** oferte = (void**)malloc(2*(lista->cp)*sizeof(void*));
    for (int i = 0; i < lista->n; i++){
        oferte[i] = lista->oferte[i];
    }
    lista->cp *= 2;
    free(lista->oferte);
    lista->oferte = oferte;
}

int AdaugaOferta(ListaOferte* l, Oferta* oferta){
//    for (int i = 0; i < l->n; i++)
//        if (Egalitate(l->oferte[i], oferta))
//            return -1;
    if (l->n <= l->cp-1)
        l->oferte[l->n] = oferta;
    else{
        RedimensionareLista(l);
        l->oferte[l->n] = oferta;
    }
    l->n++;
    return 0;
}

void AdaugareLista(ListaOferte* list,ListaOferte* list_add){
    if(list->n==list->cp)
        RedimensionareLista(list);
    list->oferte[list->n++]=list_add;
}

void add(ListaOferte* l,void* p){
    if(l->n==l->cp)
        RedimensionareLista(l);
    l->oferte[l->n++]=p;
}

int GasesteOferta(ListaOferte* l, Oferta oferta){
    int gasit = -1;
    int i;
    for (i = 0; i < l->n; i++)
    {
        if(Egalitate(l->oferte[i], &oferta))
            gasit = i;
    }
    return gasit;
}
/*
int StergeOferta(ListaOferte* l, Oferta oferta){
    int poz = GasesteOferta(l, oferta);
    if (poz == -1)
        return -1; // nu exista oferta
    DistrugeOferta(l->oferte[poz]);
    for (int i = poz; i < (l->n) - 1; i++)
        l->oferte[i] = l->oferte[i+1];
    l->n--;
    return 0;
}
*/

int StergeOferta(ListaOferte* l, int poz){

    DistrugeOferta(l->oferte[poz-1]);
    for (int i = poz-1; i < (l->n) - 1; i++)
        l->oferte[i] = l->oferte[i+1];
    l->n--;
    return 0;
}

/*
int ModificaOferta(ListaOferte* l, Oferta* oferta_veche, Oferta* oferta_noua) {
    if (GasesteOferta(l, *oferta_veche) == -1 || GasesteOferta(l, *oferta_noua) != -1)
        return -1;
    set_tip(oferta_veche, get_tip(oferta_noua));
    set_destinatie(oferta_veche, get_destinatie(oferta_noua));
    set_data(oferta_veche, get_data(oferta_noua));
    set_pret(oferta_veche, get_pret(oferta_noua));
    return 0;
}
*/

int ModificaOferta(ListaOferte* l, int poz, Oferta* oferta_noua){
    Oferta* oferta_veche = l->oferte[poz-1];
    set_tip(oferta_veche, get_tip(oferta_noua));
    set_destinatie(oferta_veche, get_destinatie(oferta_noua));
    set_data(oferta_veche, get_data(oferta_noua));
    set_pret(oferta_veche, get_pret(oferta_noua));
    return 0;
}

ListaOferte* CopieLista(ListaOferte* list){
    ListaOferte* copy=CreeazaVid((DestroyF)(DistrugeOferta));
    while(copy->cp<list->cp)
        RedimensionareLista(copy);
    copy->n=list->n;
    for(int i=0;i<list->n;i++)
        copy->oferte[i]= CopieOferta(list->oferte[i]);
    return copy;
}
