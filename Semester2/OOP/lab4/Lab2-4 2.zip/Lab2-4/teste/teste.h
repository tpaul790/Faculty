//
// Created by Titieni Paul on 11.03.2024.
//

#ifndef LAB2_4_TESTE_H
#define LAB2_4_TESTE_H

void test_creare_produs();

void test_get_set();

void test_actualizare_pret();

void test_actualizare_cantitate();

void test_sterge_produs();

void test_sortare_dupa_pret();

void test_sortare_dupa_cantiate();

void test_filtrare_producator();

void test_filtrare_pret();

void test_filtrare_cantitate();

void test_creare_lista();

void test_adaugare_produs();

void test_find();

void run_teste();

void test_redimensionare();

#endif //LAB2_4_TESTE_H
