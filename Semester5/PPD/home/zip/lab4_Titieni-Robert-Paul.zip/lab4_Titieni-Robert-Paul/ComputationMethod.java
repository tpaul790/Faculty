package ppd.utils;

public enum ComputationMethod {
    SEQUENTIAL,
    PARALLEL
}
