package ppd;

public record ScoreRecord(int id, int score) {}
