package ppd;

public class ScoreDto {
    int id;
    int nota;

    public ScoreDto(int id, int nota) {
        this.id = id;
        this.nota = nota;
    }
}
