package ppd.constants;

public enum ComputationMethod {
    SEQUENTIAL,
    BATCH,
    BLOCK,
    DISTRIBUTION
}
