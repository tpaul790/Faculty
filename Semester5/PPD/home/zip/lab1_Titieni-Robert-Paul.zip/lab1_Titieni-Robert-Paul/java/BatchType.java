package ppd.constants;

public enum BatchType {
    ROWS,
    COLUMNS
}
