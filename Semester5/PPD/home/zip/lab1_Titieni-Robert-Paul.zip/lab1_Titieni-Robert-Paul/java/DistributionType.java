package ppd.constants;

public enum DistributionType {
    LINEAR,
    CYCLIC
}
