#ifndef DISTRIBUTIONTYPE_H
#define DISTRIBUTIONTYPE_H

enum class DistributionType {
    LINEAR,
    CYCLIC
};

#endif //DISTRIBUTIONTYPE_H
