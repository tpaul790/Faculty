#ifndef MATRIXTYPE_H
#define MATRIXTYPE_H

enum class MatrixType {
    DYNAMIC,
    STATIC
};
#endif //MATRIXTYPE_H
