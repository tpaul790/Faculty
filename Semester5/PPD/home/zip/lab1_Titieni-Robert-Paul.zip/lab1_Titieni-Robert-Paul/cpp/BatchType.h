#ifndef BATCHTYPE_H
#define BATCHTYPE_H

enum class BatchType {
    ROWS,
    COLUMNS
};

#endif //BATCHTYPE_H
